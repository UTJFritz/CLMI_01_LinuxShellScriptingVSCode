#!/bin/bash
for (( v=1; v <= 10; v++ ))
do
echo "value is $v"
done