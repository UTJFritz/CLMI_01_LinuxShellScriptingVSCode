#!/usr/bin/python3
str = "Welcome to Python scripting world"
print(str.find("scripting"))