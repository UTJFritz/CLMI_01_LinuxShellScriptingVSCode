#!/usr/bin/python3
str = "Welcome to Python scripting world" 
str2 = str.replace("Python", "Shell")
print(str2)