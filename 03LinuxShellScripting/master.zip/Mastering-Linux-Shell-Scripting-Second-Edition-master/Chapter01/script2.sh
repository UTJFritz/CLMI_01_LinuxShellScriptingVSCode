# The script2.sh script
#!/bin/bash
echo $name