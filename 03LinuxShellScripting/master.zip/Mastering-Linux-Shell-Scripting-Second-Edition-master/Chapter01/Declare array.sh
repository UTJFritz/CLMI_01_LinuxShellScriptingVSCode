#!/bin/bash
myarr=(one two three four five)
echo ${myarr[1]} #prints two which is the second element