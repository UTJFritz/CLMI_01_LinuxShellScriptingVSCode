#!/bin/bash
myarr=(one two three four five)
echo ${myarr[*]}