#!/bin/bash
#Author: @likegeeks
if [ "mokhtar" = "Mokhtar" ] 
then
echo "Strings are identical"
else
echo "Strings are not identical"
fi